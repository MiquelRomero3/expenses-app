import { useState } from "react";
import "./App.css";

type Expense = {
  id: number;
  amount: number;
  category: string;
  date: string;
};

function App() {
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("");
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem("expenses");
    return saved ? JSON.parse(saved) : [];
  });

  const addExpense = () => {
    if (!amount || !category) return;

    const newExpense: Expense = {
      id: Date.now(),
      amount: parseFloat(amount),
      category,
      date: new Date().toISOString(),
    };

    const updated = [newExpense, ...expenses];
    setExpenses(updated);
    localStorage.setItem("expenses", JSON.stringify(updated));

    setAmount("");
    setCategory("");
  };

  const total = expenses.reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="app">
      <div className="container">

        <header className="header">
          <h1>💸 Expenses</h1>
          <p>Control mensual de despeses</p>
        </header>

        <div className="card">
          <h2>Nou gasto</h2>

          <input
            type="number"
            placeholder="Import (€)"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />

          <input
            type="text"
            placeholder="Categoria (cafè, menjar...)"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          />

          <button onClick={addExpense}>Afegir despesa</button>
        </div>

        <div className="summary">
          <div className="total">
            <span>Total gastat</span>
            <h2>{total.toFixed(2)} €</h2>
          </div>
        </div>

        <div className="list">
          {expenses.map((e) => (
            <div key={e.id} className="item">
              <div>
                <strong>{e.category}</strong>
                <small>{new Date(e.date).toLocaleDateString()}</small>
              </div>
              <span>{e.amount.toFixed(2)} €</span>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}

export default App;