import { useState } from "react";
import type { Expense, RecurringExpense } from "../constants";
import type { MonthlySettings } from "../App";
import { MONTHS } from "../constants";

export type UserProfile = {
  name: string;
  email: string;
};

type SettingsProps = {
  budget: number;
  onBudgetChange: (value: number) => void;
  profile: UserProfile;
  onProfileChange: (p: UserProfile) => void;
  expenses: Expense[];
  recurring: RecurringExpense[];
  salary: number;
  onSalaryChange: (val: number) => void;
  savingsGoal: number;
  onSavingsGoalChange: (val: number) => void;
  monthlySettings: Record<string, MonthlySettings>;
  onMonthlySettingsChange: (year: number, monthIdx: number, s: MonthlySettings) => Promise<void>;
  onLogout: () => void;
};

function Settings({
  budget, onBudgetChange,
  profile, expenses, recurring,
  salary, onSalaryChange,
  savingsGoal, onSavingsGoalChange,
  monthlySettings, onMonthlySettingsChange,
  onLogout,
}: SettingsProps) {
  const [notifications, setNotifications] = useState(true);

  const [editingBudget, setEditingBudget] = useState(false);
  const [budgetInput, setBudgetInput]     = useState(String(budget));

  const [editingSalary, setEditingSalary]       = useState(false);
  const [salaryInput, setSalaryInput]           = useState(String(salary || ""));
  const [savingsGoalInput, setSavingsGoalInput] = useState(String(savingsGoal || ""));

  // ── Override per mes concret ───────────────────────────────────────────────
  const now              = new Date();
  const currentYear      = now.getFullYear();
  const currentMonthIdx  = now.getMonth();

  // Mostrem els darrers 6 mesos per poder-los configurar
  const editableMonths = Array.from({ length: 6 }, (_, i) => {
    const idx = (currentMonthIdx - 5 + i + 12) % 12;
    return idx;
  });

  const [editingMonthIdx, setEditingMonthIdx]     = useState<number | null>(null);
  const [monthBudgetInput, setMonthBudgetInput]   = useState("");
  const [monthSalaryInput, setMonthSalaryInput]   = useState("");
  const [monthSavingsInput, setMonthSavingsInput] = useState("");

  const openMonthEdit = (monthIdx: number) => {
    const key = `${currentYear}-${String(monthIdx + 1).padStart(2, "0")}`;
    const existing = monthlySettings[key];
    setMonthBudgetInput(String(existing?.budget ?? budget));
    setMonthSalaryInput(String(existing?.salary ?? salary));
    setMonthSavingsInput(String(existing?.savingsGoal ?? savingsGoal));
    setEditingMonthIdx(monthIdx);
  };

  const saveMonthSettings = async () => {
    if (editingMonthIdx === null) return;
    const b = parseFloat(monthBudgetInput);
    const s = parseFloat(monthSalaryInput);
    const g = parseFloat(monthSavingsInput);
    if (!isNaN(b) && !isNaN(s)) {
      await onMonthlySettingsChange(currentYear, editingMonthIdx, {
        budget:      b,
        salary:      s,
        savingsGoal: isNaN(g) ? 0 : g,
      });
    }
    setEditingMonthIdx(null);
  };

  const saveBudget = () => {
    const val = parseFloat(budgetInput);
    if (!isNaN(val) && val > 0) onBudgetChange(val);
    setEditingBudget(false);
  };

  const saveSalary = () => {
    const s = parseFloat(salaryInput);
    const g = parseFloat(savingsGoalInput);
    if (!isNaN(s) && s > 0) onSalaryChange(s);
    if (!isNaN(g) && g > 0) onSavingsGoalChange(g);
    setEditingSalary(false);
  };

  const exportData = () => {
    const data = JSON.stringify(expenses, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href     = url;
    a.download = `despeses_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const initial = profile.email?.trim()[0]?.toUpperCase() || "?";
  const totalRecurring = recurring.reduce((s, r) => s + r.amount, 0);
  const recommendedBudget = salary > 0 && savingsGoal > 0
    ? salary - savingsGoal - totalRecurring
    : null;
  const isRecommendedApplied = recommendedBudget !== null && budget === recommendedBudget;

  return (
    <>
      <div className="header settings-header">
        <p className="settings-header-title">Configuració</p>
      </div>

      <div className="body settings-body">

        {/* Perfil */}
        <div className="settings-profile-card">
          <div className="settings-avatar">{initial}</div>
          <div className="settings-profile-info">
            <p className="settings-profile-email">{profile.email || "Sense correu"}</p>
            <p className="settings-profile-status">
              <span className="settings-status-dot" />
              Compte personal actiu
            </p>
          </div>
        </div>

        {/* Sou i estalvi */}
        <p className="settings-section-label">SOU I ESTALVI</p>
        <div className="settings-card">
          <div className="settings-row clickable" onClick={() => { setSalaryInput(String(salary || "")); setSavingsGoalInput(String(savingsGoal || "")); setEditingSalary(true); }}>
            <div className="settings-row-icon" style={{ background: "#d1fae5" }}><span>💰</span></div>
            <div className="settings-row-info">
              <p className="settings-row-title">Sou net mensual</p>
              <p className="settings-row-sub">{salary > 0 ? `${salary}€` : "No configurat"}</p>
            </div>
            <button className="settings-edit-btn">Edita</button>
          </div>

          <div className="settings-divider" />

          <div className="settings-row clickable" onClick={() => { setSalaryInput(String(salary || "")); setSavingsGoalInput(String(savingsGoal || "")); setEditingSalary(true); }}>
            <div className="settings-row-icon" style={{ background: "#dbeafe" }}><span>🎯</span></div>
            <div className="settings-row-info">
              <p className="settings-row-title">Objectiu d'estalvi</p>
              <p className="settings-row-sub">{savingsGoal > 0 ? `${savingsGoal}€ / mes` : "No configurat"}</p>
            </div>
            <button className="settings-edit-btn">Edita</button>
          </div>

          {recommendedBudget !== null && (
            <div className="settings-recommendation">
              <div className="settings-recommendation-top">
                <span>💡</span>
                <p>Pressupost recomanat: <strong>{recommendedBudget}€/mes</strong></p>
                {!isRecommendedApplied && (
                  <button
                    className="settings-apply-btn"
                    onClick={() => onBudgetChange(recommendedBudget)}
                  >
                    Aplica
                  </button>
                )}
                {isRecommendedApplied && (
                  <span className="settings-applied-badge">✓ Aplicat</span>
                )}
              </div>
              <div className="settings-recommendation-breakdown">
                <span>Sou {salary}€</span>
                <span>− Estalvi {savingsGoal}€</span>
                {totalRecurring > 0 && <span>− Hàbits {totalRecurring}€</span>}
                <span className="settings-breakdown-result">= {recommendedBudget}€</span>
              </div>
            </div>
          )}
        </div>

        {/* Pressupost global */}
        <p className="settings-section-label">PRESSUPOST PER DEFECTE</p>
        <div className="settings-card">
          <div className="settings-row">
            <div className="settings-row-icon" style={{ background: "#ede9fe" }}><span>$</span></div>
            <div className="settings-row-info">
              <p className="settings-row-title">Pressupost mensual</p>
              <p className="settings-row-sub">{budget}€ per mes</p>
            </div>
            <button className="settings-edit-btn" onClick={() => { setBudgetInput(String(budget)); setEditingBudget(true); }}>Edita</button>
          </div>
        </div>

        {/* Configuració per mes */}
        <p className="settings-section-label">CONFIGURACIÓ PER MES</p>
        <div className="settings-card">
          {editableMonths.map((monthIdx, i) => {
            const key      = `${currentYear}-${String(monthIdx + 1).padStart(2, "0")}`;
            const override = monthlySettings[key];
            const isLast   = i === editableMonths.length - 1;
            return (
              <div key={monthIdx}>
                <div className="settings-row clickable" onClick={() => openMonthEdit(monthIdx)}>
                  <div className="settings-row-icon" style={{ background: monthIdx === currentMonthIdx ? "#dbeafe" : "#f3f4f6" }}>
                    <span>{monthIdx === currentMonthIdx ? "📅" : "🗓"}</span>
                  </div>
                  <div className="settings-row-info">
                    <p className="settings-row-title">
                      {MONTHS[monthIdx]} {currentYear}
                      {monthIdx === currentMonthIdx && <span style={{ color: "#3b82f6", fontSize: "0.7rem", marginLeft: "6px" }}>actual</span>}
                    </p>
                    <p className="settings-row-sub">
                      {override
                        ? `${override.budget}€ · sou ${override.salary}€`
                        : `Per defecte (${budget}€ · sou ${salary}€)`}
                    </p>
                  </div>
                  <button className="settings-edit-btn">
                    {override ? "Edita" : "Personalitza"}
                  </button>
                </div>
                {!isLast && <div className="settings-divider" />}
              </div>
            );
          })}
        </div>

        {/* Preferències */}
        <p className="settings-section-label">PREFERÈNCIES</p>
        <div className="settings-card">
          <div className="settings-row">
            <div className="settings-row-icon" style={{ background: "#fef3c7" }}><span>🔔</span></div>
            <div className="settings-row-info">
              <p className="settings-row-title">Notificacions</p>
              <p className="settings-row-sub">Alertes de pressupost</p>
            </div>
            <button className={`settings-toggle${notifications ? " on" : ""}`} onClick={() => setNotifications(!notifications)}>
              <span className="settings-toggle-knob" />
            </button>
          </div>
        </div>

        {/* Dades */}
        <p className="settings-section-label">DADES</p>
        <div className="settings-card">
          <div className="settings-row clickable" onClick={exportData}>
            <div className="settings-row-icon" style={{ background: "#dbeafe" }}><span>↓</span></div>
            <div className="settings-row-info">
              <p className="settings-row-title">Exportar dades</p>
              <p className="settings-row-sub">JSON</p>
            </div>
            <span className="settings-chevron">›</span>
          </div>

          <div className="settings-divider" />

          <div className="settings-row">
            <div className="settings-row-icon" style={{ background: "#d1fae5" }}><span>🛡</span></div>
            <div className="settings-row-info">
              <p className="settings-row-title">Privacitat</p>
              <p className="settings-row-sub">Dades sincronitzades amb Supabase</p>
            </div>
            <span className="settings-chevron">›</span>
          </div>
        </div>

        {/* Sessió */}
        <p className="settings-section-label">SESSIÓ</p>
        <div className="settings-card">
          <div className="settings-row clickable" onClick={onLogout}>
            <div className="settings-row-icon" style={{ background: "#fee2e2" }}><span>🚪</span></div>
            <div className="settings-row-info">
              <p className="settings-row-title" style={{ color: "#dc2626" }}>Tancar sessió</p>
              <p className="settings-row-sub">Sortir del compte actual</p>
            </div>
            <span className="settings-chevron">›</span>
          </div>
        </div>

      </div>

      {/* MODAL PRESSUPOST GLOBAL */}
      {editingBudget && (
        <div className="modal-overlay" onClick={() => setEditingBudget(false)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-handle" />
            <h2>Pressupost mensual</h2>
            <input type="number" placeholder="Import (€)" value={budgetInput} onChange={(e) => setBudgetInput(e.target.value)} autoFocus />
            <button className="btn-primary" onClick={saveBudget}>Guardar</button>
            <button className="btn-secondary" onClick={() => setEditingBudget(false)}>Cancel·lar</button>
          </div>
        </div>
      )}

      {/* MODAL SOU I ESTALVI GLOBAL */}
      {editingSalary && (
        <div className="modal-overlay" onClick={() => setEditingSalary(false)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-handle" />
            <h2>Sou i objectiu d'estalvi</h2>
            <input type="number" placeholder="Sou net mensual (€)" value={salaryInput} onChange={(e) => setSalaryInput(e.target.value)} autoFocus />
            <input type="number" placeholder="Objectiu d'estalvi mensual (€)" value={savingsGoalInput} onChange={(e) => setSavingsGoalInput(e.target.value)} />
            {salaryInput && savingsGoalInput && (
              <p className="modal-hint">
                💡 Pressupost recomanat: <strong>{Math.max(0, parseFloat(salaryInput) - parseFloat(savingsGoalInput) - totalRecurring)}€</strong>
                {totalRecurring > 0 && <span className="modal-hint-detail"> ({parseFloat(salaryInput)}€ − {parseFloat(savingsGoalInput)}€ estalvi − {totalRecurring}€ hàbits)</span>}
              </p>
            )}
            <button className="btn-primary" onClick={saveSalary}>Guardar</button>
            <button className="btn-secondary" onClick={() => setEditingSalary(false)}>Cancel·lar</button>
          </div>
        </div>
      )}

      {/* MODAL CONFIGURACIÓ MES CONCRET */}
      {editingMonthIdx !== null && (
        <div className="modal-overlay" onClick={() => setEditingMonthIdx(null)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-handle" />
            <h2>{MONTHS[editingMonthIdx]} {currentYear}</h2>
            <p className="modal-hint" style={{ marginBottom: "0.5rem" }}>
              Deixa els valors per defecte o personalitza aquest mes concret.
            </p>
            <input
              type="number"
              placeholder={`Pressupost (per defecte: ${budget}€)`}
              value={monthBudgetInput}
              onChange={(e) => setMonthBudgetInput(e.target.value)}
              autoFocus
            />
            <input
              type="number"
              placeholder={`Sou net (per defecte: ${salary}€)`}
              value={monthSalaryInput}
              onChange={(e) => setMonthSalaryInput(e.target.value)}
            />
            <input
              type="number"
              placeholder={`Objectiu estalvi (per defecte: ${savingsGoal}€)`}
              value={monthSavingsInput}
              onChange={(e) => setMonthSavingsInput(e.target.value)}
            />
            {monthSalaryInput && monthBudgetInput && (
              <p className="modal-hint">
                💡 Estalvi previst: <strong>
                  {(parseFloat(monthSalaryInput) - parseFloat(monthBudgetInput)).toFixed(2)}€
                </strong>
              </p>
            )}
            <button className="btn-primary" onClick={saveMonthSettings}>Guardar</button>
            <button className="btn-secondary" onClick={() => setEditingMonthIdx(null)}>Cancel·lar</button>
          </div>
        </div>
      )}
    </>
  );
}

export default Settings;