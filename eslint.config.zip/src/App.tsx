import { useState } from "react";
import homeIcon from "./assets/home.svg";
import grafIcon from "./assets/graf.svg";
import settingsIcon from "./assets/settings.svg";
import "./App.css";

// ─── Types ───────────────────────────────────────────────────────────────────
type Expense = {
  id: number;
  amount: number;
  category: string;
  date: string;
  note?: string;
};

// ─── Category config ─────────────────────────────────────────────────────────
const CATEGORIES: Record<string, { emoji: string; color: string; bg: string }> = {
  Cafè:          { emoji: "☕", color: "#f59e0b", bg: "#fef3c7" },
  Menjar:        { emoji: "🍔", color: "#10b981", bg: "#d1fae5" },
  Alimentació:   { emoji: "🛒", color: "#10b981", bg: "#d1fae5" },
  Roba:          { emoji: "👕", color: "#ec4899", bg: "#fce7f3" },
  Transport:     { emoji: "🚌", color: "#3b82f6", bg: "#dbeafe" },
  Salut:         { emoji: "💊", color: "#ef4444", bg: "#fee2e2" },
  Oci:           { emoji: "🎬", color: "#8b5cf6", bg: "#ede9fe" },
  Lleure:        { emoji: "🎬", color: "#8b5cf6", bg: "#ede9fe" },
  Subscripcions: { emoji: "📱", color: "#f97316", bg: "#ffedd5" },
  Serveis:       { emoji: "⚡", color: "#f97316", bg: "#ffedd5" },
  Altres:        { emoji: "📦", color: "#6b7280", bg: "#f3f4f6" },
};

function getCfg(cat: string) {
  for (const k of Object.keys(CATEGORIES)) {
    if (cat.toLowerCase().includes(k.toLowerCase())) return CATEGORIES[k];
  }
  return CATEGORIES["Altres"];
}

// ─── Constants ────────────────────────────────────────────────────────────────
const BUDGET = 400;
const MONTHS = ["Gen","Feb","Mar","Abr","Mai","Jun","Jul","Ago","Set","Oct","Nov","Des"];

// ─── App ──────────────────────────────────────────────────────────────────────
function App() {
  const [amount, setAmount]       = useState("");
  const [category, setCategory]   = useState("");
  const [note, setNote]           = useState("");
  const [showForm, setShowForm]   = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const CAT_KEYS = Object.keys(CATEGORIES).filter(
  (k) => !["Alimentació", "Lleure"].includes(k)
  );
  const [tab, setTab] = useState<"home" | "history" | "settings">("home");
  const [showAllExpenses, setShowAllExpenses] = useState(false);
  const [showAllCats, setShowAllCats] = useState(false);
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem("expenses");
    return saved ? JSON.parse(saved) : [];
  });

  const addExpense = () => {
    if (!amount || !category) return;
    const newExpense: Expense = {
      id: Date.now(),
      amount: parseFloat(amount),
      category,
      date: new Date().toISOString(),
      note: note || undefined,
    };
    const updated = [newExpense, ...expenses];
    setExpenses(updated);
    localStorage.setItem("expenses", JSON.stringify(updated));
    setAmount(""); setCategory(""); setNote("");
    setShowForm(false);
  };

  const deleteExpense = (id: number) => {
    const updated = expenses.filter((e) => e.id !== id);
    setExpenses(updated);
    localStorage.setItem("expenses", JSON.stringify(updated));
  };

  // Filtered by selected month
  const monthExpenses = expenses.filter((e) => {
    const d = new Date(e.date);
    return d.getMonth() === selectedMonth && d.getFullYear() === new Date().getFullYear();
  });

  const total   = monthExpenses.reduce((s, e) => s + e.amount, 0);
  const pct     = Math.min((total / BUDGET) * 100, 100);
  const over    = total > BUDGET;
  const remaining = BUDGET - total;

  // Today's spend
  const todayStr = new Date().toDateString();
  const todayTotal = expenses
    .filter((e) => new Date(e.date).toDateString() === todayStr)
    .reduce((s, e) => s + e.amount, 0);

  // Daily average this month
  const dayOfMonth = new Date().getDate();
  const dailyAvg = dayOfMonth > 0 ? total / dayOfMonth : 0;

  // Category totals
  const catMap: Record<string, number> = {};
  monthExpenses.forEach((e) => {
    const k = e.category; catMap[k] = (catMap[k] || 0) + e.amount;
  });
  const catTotals = Object.entries(catMap)
    .sort((a, b) => b[1] - a[1]);
  const maxCat = catTotals[0]?.[1] || 1;

  const visibleExpenses = showAllExpenses
  ? monthExpenses
  : monthExpenses.slice(0, 6);

  // Month chips
  const currentMonthIdx = new Date().getMonth();
  const visibleMonths = Array.from({ length: 6 }, (_, i) => (currentMonthIdx - 5 + i + 12) % 12);

  return (
    <div className="app">
      <div className="container">

        {/* ── HEADER ── */}
        <div className="header">
          <div className="header-top-row">
            <div>
              <p className="header-eyebrow">Pressupost mensual</p>
              <p className="header-month">
                {MONTHS[selectedMonth]} 2026 <span className="chevron">›</span>
              </p>
            </div>
            <button className="bell-btn">🔔</button>
          </div>

          <div className="header-balance">
            <div>
              <p className="header-balance-label">Total gastat</p>
              <p className="header-balance-amount">
                {total.toFixed(2)}€
                <span className="header-balance-budget"> / {BUDGET}€</span>
              </p>
            </div>
          </div>

          <div className="progress-wrap">
            <div className="progress-bg">
              <div
                className={`progress-fill${over ? " over" : ""}`}
                style={{ width: `${pct}%` }}
              />
            </div>
            <div className="progress-labels">
              <span>{Math.round(pct)}% usat</span>
              <span className={over ? "over-text" : ""}>
                {over
                  ? `${(total - BUDGET).toFixed(2)}€ passat`
                  : `${remaining.toFixed(2)}€ restants`}
              </span>
            </div>
          </div>
        </div>

        {/* ── BODY ── */}
        <div className="body">

          {/* Month tabs */}
          <div className="month-scroll">
            {visibleMonths.map((m) => (
              <button
                key={m}
                className={`month-chip${m === selectedMonth ? " active" : ""}`}
                onClick={() => setSelectedMonth(m)}
              >
                {MONTHS[m]}
              </button>
            ))}
          </div>

          {/* Stats cards */}
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-header">
                <span className="stat-icon green">↓</span>
                <span className="stat-label">Avui gastat</span>
              </div>
              <p className="stat-value">{todayTotal.toFixed(2)}€</p>
            </div>
            <div className="stat-card">
              <div className="stat-header">
                <span className="stat-icon orange">↑</span>
                <span className="stat-label">Mitjana diària</span>
              </div>
              <p className="stat-value">{dailyAvg.toFixed(2)}€</p>
            </div>
          </div>

          {/* Categories */}
          {catTotals.length > 0 && (
            <div className="section">
              <div className="section-header">
                <span className="section-title">Per categories</span>
                <button className="section-link" onClick={() => setShowAllCats(!showAllCats)}>
                  {showAllCats ? "Veure-ne menys ›" : "Veure-les totes ›"}
                </button>
              </div>
              <div className="cat-list">
                {(showAllCats ? catTotals : catTotals.slice(0, 4)).map(([cat, amt]) => {
                  const cfg = getCfg(cat);
                  const barPct = Math.round((amt / maxCat) * 100);
                  return (
                    <div key={cat} className="cat-row">
                      <div className="cat-icon" style={{ background: cfg.bg }}>
                        <span>{cfg.emoji}</span>
                      </div>
                      <div className="cat-info">
                        <div className="cat-labels">
                          <span className="cat-name">{cat}</span>
                          <span className="cat-amount">{amt.toFixed(2)}€</span>
                        </div>
                        <div className="cat-bar-bg">
                          <div
                            className="cat-bar-fill"
                            style={{ width: `${barPct}%`, background: cfg.color }}
                          />
                        </div>
                      </div>
                      <span className="cat-pct">{Math.round((amt / total) * 100)}%</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Recent expenses */}
          <div className="section">
            <div className="section-header">
              <span className="section-title">Despeses recents</span>
              <button className="section-link" onClick={() => setShowAllExpenses(!showAllExpenses)}>
                {showAllExpenses ? "Veure-ne menys ›" : "Veure-les totes ›"}
              </button>
            </div>
            <div className="expense-card">
              {visibleExpenses.length === 0 && (
                  <p className="empty">Cap despesa aquest mes</p>
                )}

                {visibleExpenses.map((e) => {
                const cfg = getCfg(e.category);
                return (
                  <div key={e.id} className="expense-row">
                    <div className="expense-icon" style={{ background: cfg.bg }}>
                      <span>{cfg.emoji}</span>
                    </div>
                    <div className="expense-info">
                      <p className="expense-name">{e.note || e.category}</p>
                      <p className="expense-date">
                        {new Date(e.date).toLocaleDateString("ca-ES", {
                          day: "numeric", month: "short", hour: "2-digit", minute: "2-digit",
                        })}
                      </p>
                    </div>
                    <div className="expense-right">
                      <span className="expense-amount">-{e.amount.toFixed(2)}€</span>
                      <button className="delete-btn" onClick={() => deleteExpense(e.id)}>✕</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* ── NAV BAR ── */}
        <nav className="nav-bar">
          <button className={`nav-item${tab === "home" ? " active" : ""}`} onClick={() => setTab("home")}>
            <img src={homeIcon} className="nav-icon" />
            <span>Inici</span>
          </button>
          <button className={`nav-item${tab === "history" ? " active" : ""}`} onClick={() => setTab("history")}>
            <img src={grafIcon} className="nav-icon" />
            <span>Historial</span>
          </button>
          <button className={`nav-item${tab === "settings" ? " active" : ""}`} onClick={() => setTab("settings")}>
            <img src={settingsIcon} className="nav-icon" />
            <span>Config.</span>
          </button>
        </nav>
      </div>

      {/* ── MODAL ── */}
      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal-card" onClick={(ev) => ev.stopPropagation()}>
            <div className="modal-handle" />
            <h2>Nova despesa</h2>
            <input
              type="number"
              placeholder="Import (€)"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <div className="cat-picker-grid">
              {CAT_KEYS.map((key) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setCategory(key)}
                  className={`cat-pill ${category === key ? "selected" : ""}`}
                >
                  <span>{CATEGORIES[key].emoji}</span>
                  <span>{key}</span>
                </button>
              ))}
            </div>
            <input
              type="text"
              placeholder="Nota (opcional)"
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
            <button className="btn-primary" onClick={addExpense}>Afegir despesa</button>
            <button className="btn-secondary" onClick={() => setShowForm(false)}>Cancel·lar</button>
          </div>
        </div>
      )}

      {/* ── FAB ── */}
      <button className="fab" onClick={() => setShowForm(true)}>+</button>
    </div>
  );
}

export default App;
